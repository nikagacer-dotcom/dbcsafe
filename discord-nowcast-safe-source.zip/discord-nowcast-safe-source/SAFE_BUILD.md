# discord-nowcast — privacy-hardened source build

This is a modified source snapshot based on the user-provided `discord-nowcast-main.zip` (the project source). It is **not** the original release EXE and it is **not certified malware-free**.

## Disabled in this build

- Automatic startup registration, registry Run-key changes and desktop shortcut creation.
- Automatic GitHub release checks.
- Cover lookup, cover uploads and user-selected picture uploads.
- Lyrics lookups to lrclib.net.
- Remote image fetching in the status preview.
- Images in Discord activities (the activity text/timing still works).
- Automatic network image fetching in the preview.

The UI options for autostart and automatic update checks were removed in this snapshot.

## Remaining intended behavior

- Reads Windows media-session metadata and selected window titles locally.
- Connects to the Discord desktop application's local IPC interface to publish activity.
- Saves local settings/logs.
- Buttons and menu items may open a web page only after the user explicitly clicks them.

## Build

On Windows 10/11 with .NET Framework 4.8 installed, open PowerShell in this folder and run:

```powershell
.\build.ps1
```

The output is `discord-nowcast.exe`. Do not add it to antivirus exclusions. Scan the resulting EXE before considering use. A source rebuild can still be flagged by antivirus heuristics; a clean scan is not a guarantee.

## Audit limitations

This source was statically reviewed and modified to disable the project's outbound HTTP features and persistence. It was not compiled or dynamically sandbox-tested in this environment. The original VirusTotal result (7/70) applies to the separately supplied original EXE, not to this modified source or any future build.
