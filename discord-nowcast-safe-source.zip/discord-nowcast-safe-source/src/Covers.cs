using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Nowcast
{
    // The cover: the picture the player handed to Windows, the same one its own
    // flyout shows. Discord only shows pictures by URL, so it goes to a host
    // (Hosts). Only when the player gives no picture, or no host takes it,
    // the album art from the iTunes search is used, if the same artist and
    // title are found there; the player's picture replaces it when it comes.
    static class Covers
    {
        // A cover in hand: its link, where it came from, when to upload the
        // picture again (the host will delete it) and when the link is gone.
        public class Entry
        {
            public string Url;
            public bool FromITunes;
            public DateTime Renew;
            public DateTime Gone;
        }

        // What a lookup in the background brought: a cover, or that it failed
        // and is to be tried again; Answered: iTunes gave its answer, found or not.
        public class Result
        {
            public Entry Entry;
            public string Print;
            public bool Failed;
            public bool Answered;
            public bool Permanent;
            public long RetryVersion;
            public string Error;
        }

        static readonly Dictionary<string, Entry> cache = new Dictionary<string, Entry>();
        // Uploads by the picture's fingerprint: a cover shared by an album's tracks goes up once.
        static readonly Dictionary<string, Entry> byPrint = new Dictionary<string, Entry>();
        // When a track may be looked at again, and its failures in a row.
        static readonly Dictionary<string, DateTime> retryAt = new Dictionary<string, DateTime>();
        static readonly Dictionary<string, int> failures = new Dictionary<string, int>();
        // Tracks iTunes has answered for: one search per track. A search that
        // failed is not an answer and is tried again.
        static readonly HashSet<string> searched = new HashSet<string>();
        // iTunes turned the searches down (403, 429): none until then.
        static DateTime iTunesPausedUntil;
        static readonly object iTunesBook = new object();

        // What was last taken from each player: its track, a fingerprint of the
        // picture and the album. Right after a track changes Windows can still
        // hand over the previous track's picture; this is how that is noticed.
        class Seen
        {
            public string Key;
            public string Print;
            public string Album;
        }

        static readonly Dictionary<string, Seen> lastByApp = new Dictionary<string, Seen>();
        // Times a track's picture was the same as the previous track's.
        static readonly Dictionary<string, int> staleLooks = new Dictionary<string, int>();
        // Times a track had no picture from the player at all.
        static readonly Dictionary<string, int> noPicture = new Dictionary<string, int>();
        // How many times, a second apart, to look for the player's picture before
        // turning to iTunes: browsers hand it over a few seconds after the track starts.
        const int PictureLooks = 5;
        // After that, and while an iTunes cover stands in, the player is asked this often.
        const int LookEvery = 5;
        // The track looked for last, and the settings the covers in hand were found with.
        static string current;
        static string mode;

        // Stand-ins for the tests: the clock, the player's picture, the upload and iTunes.
        public static Func<DateTime> Now = delegate { return DateTime.Now; };
        public static Func<Track, byte[]> ReadPicture = Media.ReadThumbnail;
        public static Func<byte[], Hosts.Uploaded> Upload = delegate(byte[] image) { throw new NotSupportedException("Uploads disabled in safe build."); };
        public static Func<Track, Result> LookUp = delegate(Track track) { return new Result { Failed = true, Permanent = true }; };
        public static Func<byte[], string, Hosts.Uploaded> UploadOwn = delegate(byte[] image, string slot) { throw new NotSupportedException("Uploads disabled in safe build."); };

        // Raised when a lookup is done, so that the status goes out at once and
        // does not wait for the engine's next round.
        public static event Action Ready;

        static void Notify()
        {
            var handler = Ready;
            if (handler != null) handler();
        }
        // Lookups and uploads under way. They run in the background: a slow
        // host held the whole status back for up to a minute.
        static readonly Dictionary<string, Task<Result>> pending = new Dictionary<string, Task<Result>>();

        // The URL of the track's cover, or null when there is none yet; the
        // status goes without it and gets it when the lookup is done.
        // The settings say where from first: the player's picture or iTunes.
        public static string Find(Track track, Settings settings)
        {
            // Safe build: no remote cover search or image uploads.
            return null;
        }

        // What a finished lookup brought, into the books.
        static void Take(string key, Result result, bool iTunesFirst, DateTime now)
        {
            if (result.Answered) searched.Add(key);
            if (result.Entry != null)
            {
                cache[key] = result.Entry;
                if (result.Print != null) byPrint[result.Print] = result.Entry;
                failures.Remove(key);
                retryAt.Remove(key);
                // The player's own picture is still looked for.
                if (result.Entry.FromITunes && !iTunesFirst) retryAt[key] = now.AddSeconds(LookEvery);
            }
            else if (result.Failed)
            {
                // 2, 4, 8, 16, 32 s, then once a minute while the track plays.
                int count;
                failures.TryGetValue(key, out count);
                failures[key] = ++count;
                retryAt[key] = now.AddSeconds(Math.Min(60, 1 << count));
            }
            else
            {
                retryAt[key] = now.AddSeconds(LookEvery);
            }
        }

        // The link in hand while a better one is on its way, or null.
        static string Usable(string key, DateTime now)
        {
            Entry entry;
            return cache.TryGetValue(key, out entry) && now < entry.Gone ? entry.Url : null;
        }

        // Everything forgotten: the settings changed, or the books grew too long.
        public static void Reset()
        {
            cache.Clear();
            byPrint.Clear();
            retryAt.Clear();
            failures.Clear();
            searched.Clear();
            staleLooks.Clear();
            noPicture.Clear();
            lastByApp.Clear();
            pending.Clear();
            current = null;
        }

        // Runs a lookup in the background and tells the engine when it is done.
        static void Start(string key, Func<Result> work)
        {
            var task = Task.Run(delegate
            {
                try
                {
                    return work();
                }
                catch (Exception e)
                {
                    Log.Write("Cover lookup failed: " + Message(e));
                    return new Result { Failed = true };
                }
            });
            pending[key] = task;
            task.ContinueWith(t => Notify());
        }

        // In the background: the player's picture, made ready and uploaded.
        // orITunes: when no host takes it, the album art from iTunes instead
        // (a host that bans the IP or is down left the status with no cover).
        static Result FromPlayer(Track track, byte[] image, string print, bool orITunes)
        {
            var begin = Now();
            try
            {
                var entry = Uploaded(Upload(image));
                Log.Write("Cover from the player: " + Engine.Describe(track) + " " + entry.Url + " (" + (int)(Now() - begin).TotalMilliseconds + " ms)");
                return new Result { Entry = entry, Print = print };
            }
            catch (Exception e)
            {
                Log.Write("Cover not uploaded, will try again: " + Message(e));
                if (!orITunes) return new Result { Failed = true };
                var found = LookUp(track);
                found.Failed = true;
                return found;
            }
        }

        // An uploaded picture's link, uploaded again a little before the host deletes it.
        static Entry Uploaded(Hosts.Uploaded uploaded)
        {
            var got = Now();
            return new Entry
            {
                Url = uploaded.Url,
                Renew = got + TimeSpan.FromTicks(uploaded.Keep.Ticks * 8 / 10),
                Gone = got + uploaded.Keep - TimeSpan.FromMinutes(10),
            };
        }

        // A picture of one's own from a file: one's own status's, or the one
        // shown when a track has no cover. Uploaded like a cover, tried again
        // the same way and renewed before the host deletes it. The file is
        // told apart by its time and size, not read every round.
        class FileState
        {
            public string Print;
            public Entry Entry;
            public Task<Result> Job;
            public DateTime RetryAt;
            public int Failures;
            public long RetryVersion;
        }

        class PictureProgress
        {
            public string Print;
            public string Message;
        }
        static readonly ConcurrentDictionary<string, PictureProgress> progress = new ConcurrentDictionary<string, PictureProgress>();

        // UI reads immutable snapshots; the file cache belongs to the engine thread.
        public static string PictureStatus(string path)
        {
            return "Remote picture uploads are disabled in this safe build.";
        }

        static void Progress(string path, string print, string message)
        {
            progress[path] = new PictureProgress { Print = print, Message = message };
        }

        static readonly ConcurrentDictionary<string, long> retryRequests = new ConcurrentDictionary<string, long>();

        public static void RetryPicture(string path)
        {
            // Remote picture uploads are disabled in this build.
        }

        static readonly Dictionary<string, FileState> files = new Dictionary<string, FileState>();

        public static string FindFile(string path)
        {
            // Safe build: local pictures are not uploaded to remote hosts.
            return null;
        }

        static string FileUsable(FileState state, DateTime now)
        {
            return state.Entry != null && now < state.Entry.Gone ? state.Entry.Url : null;
        }

        // In the background: the album art from iTunes. Its links do not expire.
        static Result FromITunes(Track track)
        {
            // Safe build: external artwork search is disabled.
            return new Result { Failed = true, Permanent = true };
        }

        static bool ITunesOpen(DateTime now)
        {
            lock (iTunesBook) return now >= iTunesPausedUntil;
        }

        // Whether the picture is still the previous track's: the title has
        // changed but Windows has not replaced the picture yet. Tracks of one
        // album share a picture and are taken at once; for others the picture
        // is read again a few times before the two are believed to be the same.
        static bool IsStale(Track track, string print)
        {
            Seen before;
            if (!lastByApp.TryGetValue(track.App, out before) || before.Key == track.Key || before.Print != print) return false;
            if (track.Album != "" && string.Equals(before.Album, track.Album, StringComparison.OrdinalIgnoreCase)) return false;
            int looks;
            staleLooks.TryGetValue(track.Key, out looks);
            staleLooks[track.Key] = ++looks;
            if (looks > 4) return false;
            Log.Write("The picture of " + Engine.Describe(track) + " is still the previous track's, looking again");
            return true;
        }

        // The album art for the same artist and title in the iTunes search, or
        // null. A video's own frame says more than an album, so videos are left
        // to the player's picture. A search finds songs with the same title by
        // other artists, so both have to match. answered: false when iTunes
        // could not be asked, and the search is to be tried again.
        static string Search(Track track, out bool answered)
        {
            // Safe build: no external artwork search.
            answered = true;
            return null;
        }

        // Lowercase letters and digits only, without (feat. …), [Remix] and the like.
        static string Norm(string text)
        {
            text = Regex.Replace(text, @"[(\[].*?[)\]]", "");
            text = Regex.Replace(text, @"\s(feat|ft)\.?\s.*$", "", RegexOptions.IgnoreCase);
            return Regex.Replace(text.ToLowerInvariant(), @"[^\p{L}\p{N}]", "");
        }

        // The same, or one starts the other: "Song" and "Song - Remastered 2011".
        static bool Alike(string found, string wanted)
        {
            if (found == wanted) return true;
            var shorter = Math.Min(found.Length, wanted.Length);
            return shorter >= 4 && (found.StartsWith(wanted) || wanted.StartsWith(found));
        }

        static string Message(Exception e)
        {
            return e.GetBaseException().Message;
        }
    }
}
