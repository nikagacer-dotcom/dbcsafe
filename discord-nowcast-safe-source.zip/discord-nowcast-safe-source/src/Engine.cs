using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace Nowcast
{
    // The work itself, on its own thread: once a second reads what plays and,
    // when it changed, sends the status to Discord.
    class Engine
    {
        readonly Discord discord = new Discord();
        readonly AutoResetEvent wake = new AutoResetEvent(false);
        readonly FileSystemWatcher watcher;
        Thread thread;
        volatile bool stopping;
        volatile bool reload;
        Settings settings;

        // What is in the status now: track key, or "none".
        string sentKey;
        long? sentStart;
        long sentDuration;
        // The last timeline the app reported, and the start worked out from it.
        string timelineKey;
        double timelinePosition;
        long timelineUpdated;
        bool timelinePlaying;
        long? timelineStart;
        double timelinePausedPosition;
        internal static Func<long> TimelineNow = delegate { return DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(); };
        bool? sentPlaying;
        // The picture in the status now: a cover's link, the settings' own picture, or null.
        string sentImage;
        // The line of the song in the status now, or null.
        string sentLyric;
        DateTime sentAt = DateTime.MinValue;
        DateTime nextConnect = DateTime.MinValue;
        DateTime? resendAt;
        string shownKey;
        // One's own status as last set, and when it started by its time.
        string ownKey;
        long ownStart;
        // The track last seen and when, to see how long its status took.
        string seenKey;
        DateTime seenAt;

        public DateTime HiddenUntil { get; private set; }
        // For the tray: one line about the status and the sessions Windows reports.
        public string Status { get; private set; }
        public List<Track> Sessions { get; private set; }

        // Publish one immutable reference so the UI never combines one track
        // with another track's cover while the engine is updating.
        internal sealed class PreviewSnapshot
        {
            public readonly Track Track;
            public readonly string Image, Lyric;
            public PreviewSnapshot(Track track, string image, string lyric)
            { Track = track; Image = image; Lyric = lyric; }
        }
        volatile PreviewSnapshot preview;
        internal PreviewSnapshot Preview { get { return preview; } }
        public event Action Changed;

        public Engine()
        {
            settings = Settings.Load();
            Status = Text.Starting;
            Sessions = new List<Track>();

            watcher = new FileSystemWatcher(Log.Folder, "config.json");
            watcher.Changed += delegate { reload = true; wake.Set(); };
            watcher.Created += delegate { reload = true; wake.Set(); };
            watcher.EnableRaisingEvents = true;

            // A cover that is done does not wait for the next round.
            Covers.Ready += delegate { wake.Set(); };
            Lyrics.Ready += delegate { wake.Set(); };
        }

        public Settings Settings
        {
            get { return settings; }
        }

        // For the diagnostics: connected, and with which application, or why not.
        public string DiscordState
        {
            get
            {
                if (discord.IsConnected) return "connected, application " + discord.ClientId;
                return "not connected" + (discord.LastMiss != null ? ": " + discord.LastMiss : "");
            }
        }

        public void Start()
        {
            // STA, like the PowerShell this grew from: the Start menu lookup is a shell object.
            thread = new Thread(Loop) { IsBackground = true, Name = "engine" };
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
        }

        public void Stop()
        {
            stopping = true;
            wake.Set();
            if (thread != null) thread.Join(5000);
            watcher.Dispose();
        }

        public void Hide(TimeSpan time)
        {
            HiddenUntil = DateTime.Now + time;
            wake.Set();
        }

        public void Show()
        {
            HiddenUntil = DateTime.MinValue;
            wake.Set();
        }

        void Loop()
        {
            // Tried again every 30 s: Windows may let the program in later.
            string lastError = null;
            while (!stopping)
            {
                try
                {
                    Media.Open();
                    break;
                }
                catch (Exception e)
                {
                    var cause = Unwrap(e);
                    var error = Describe(cause);
                    if (error != lastError) Log.Write("Media sessions unavailable: " + error);
                    lastError = error;
                    // "Class not registered": the media sessions were cut out of
                    // this Windows (custom builds), no player can be read here.
                    // "The service cannot be started, it is disabled": a tweaking
                    // tool turned off a service the media sessions need.
                    Report(cause.HResult == unchecked((int)0x80040154) ? Text.MediaRemoved
                        : cause.HResult == unchecked((int)0x80070422) ? Text.MediaServiceOff
                        : Text.MediaUnavailable);
                    wake.WaitOne(30000);
                }
            }
            string lastTickError = null;
            while (!stopping)
            {
                try
                {
                    Tick();
                    lastTickError = null;
                }
                catch (Exception e)
                {
                    // The same error every second would bury the log: once until it changes.
                    var error = e.ToString();
                    if (error != lastTickError) Log.Write("Error: " + error);
                    lastTickError = error;
                }
                wake.WaitOne(500);
            }
            if (discord.IsConnected)
            {
                try
                {
                    discord.SetActivity(null);
                }
                catch (Exception)
                {
                }
            }
            discord.Dispose();
        }

        void Tick()
        {
            if (reload)
            {
                reload = false;
                settings = Settings.Load();
                sentKey = null;
                Log.Write("Settings reloaded");
            }

            var sessions = Media.Read(settings);
            var isHidden = DateTime.Now < HiddenUntil;
            // One's own status takes the place of whatever plays.
            var isOwn = !isHidden && settings.ShowsOwn;
            var track = isHidden || isOwn ? null : Pick(sessions);
            var previous = preview;
            bool sameTrack = previous != null && previous.Track != null && track != null && previous.Track.Key == track.Key;
            preview = new PreviewSnapshot(track, sameTrack ? previous.Image : null, sameTrack ? previous.Lyric : null);
            // Turned on again later: its time counts from then.
            if (!isOwn) ownKey = null;
            Sessions = sessions;

            if (discord.IsConnected && !discord.IsAlive)
            {
                Log.Write("Discord closed the connection");
                discord.Dispose();
                nextConnect = DateTime.Now;
            }
            // Each service has its own application, named after it: another
            // service means another connection. Closing one clears its status.
            var clientId = isOwn ? settings.OwnClientIdFor()
                : track != null ? settings.ClientIdFor(track.Source)
                : (discord.ClientId ?? settings.ClientId);
            if (discord.IsConnected && (discord.ClientId != clientId || discord.ActivityName != settings.ActivityNameOverride))
            {
                Log.Write("Switching Discord activity connection: " + (isOwn ? "one's own status" : track != null ? track.Source.Name : "settings changed"));
                discord.Dispose();
                nextConnect = DateTime.Now;
            }
            if (!discord.IsConnected && DateTime.Now >= nextConnect)
            {
                if (discord.Connect(clientId, settings.ActivityNameOverride))
                {
                    sentKey = null;
                    // A Discord that is still starting up can drop the first
                    // status, so it goes once more a little later.
                    resendAt = DateTime.Now.AddSeconds(10);
                }
                else
                {
                    nextConnect = DateTime.Now.AddSeconds(3);
                }
            }

            Report(!discord.IsConnected ? (discord.IsDenied ? Text.DiscordElevated : Text.DiscordOff)
                : isHidden ? string.Format(Text.HiddenUntil, HiddenUntil)
                : isOwn ? string.Format(Text.OwnShown, settings.OwnTitle.Trim())
                : track == null ? Text.NothingPlaying
                : Describe(track));
            if (!discord.IsConnected) return;

            if (isOwn)
            {
                Own();
                return;
            }
            var key = track == null ? "none" : track.Key;
            if (track != null && seenKey != key)
            {
                seenKey = key;
                seenAt = DateTime.Now;
            }
            // The cover is looked for as soon as the track is seen, even when its
            // status has to wait for its turn. The status itself never waits for it.
            var image = track == null ? null : Activity.Image(track, settings);
            var start = track == null ? null : StartFor(track);
            bool? playing = track == null ? (bool?)null : track.IsPlaying;
            // Keep the latest seek pending until the normal four-second send slot.
            // Duration can arrive later than the title/position and needs a resend too.
            var timingChanged = TimingChanged(track, start);
            var isResend = resendAt.HasValue && DateTime.Now >= resendAt.Value;
            // Another picture for the same track: a cover that was not there when
            // the track started, one in place of the settings' own picture or of
            // an iTunes cover, or a new link for one the host is about to delete.
            var coverCame = key == sentKey && track != null && image != null && image != sentImage;
            // The line being sung, when it is wanted: the next one goes out in
            // its turn, a quick one between two turns is skipped.
            string lyric = null;
            if (track != null && settings.Lyrics && track.IsPlaying && start.HasValue && !track.Source.IsVideo)
            {
                lyric = Lyrics.Line(Lyrics.Find(track), DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - start.Value);
            }
            preview = new PreviewSnapshot(track, image, lyric);
            var lyricCame = key == sentKey && track != null && lyric != sentLyric;
            var changed = key != sentKey || playing != sentPlaying || timingChanged || isResend || coverCame || lyricCame;
            // Discord takes at most 5 updates per 20 seconds.
            if (!changed || (DateTime.Now - sentAt).TotalSeconds < 4) return;
            if (isResend) resendAt = null;

            try
            {
                if (track == null)
                {
                    discord.SetActivity(null);
                    Log.Write("Status cleared");
                }
                else
                {
                    var activity = Activity.Build(track, start, settings, lyric);
                    if (discord.SetActivity(activity) != null && Activity.UseLinks)
                    {
                        // An older Discord may not know the links on the cover and title.
                        Activity.UseLinks = false;
                        activity = Activity.Build(track, start, settings, lyric);
                        discord.SetActivity(activity);
                    }
                    // A new line of the song every few seconds would bury the log.
                    var onlyLyric = lyricCame && key == sentKey && playing == sentPlaying && !timingChanged && !isResend && !coverCame;
                    if (!onlyLyric) Log.Write("Status: " + Describe(track) + (activity.ContainsKey("assets") ? "" : " (no cover)") +
                        (key != sentKey && seenKey == key ? " [" + (int)(DateTime.Now - seenAt).TotalMilliseconds + " ms after the track was seen]" : ""));
                }
                shownKey = track == null ? null : key;
                sentKey = key;
                sentImage = image;
                sentLyric = lyric;
                sentStart = start;
                sentDuration = DurationMillis(track);
                sentPlaying = playing;
                sentAt = DateTime.Now;
            }
            catch (Exception e)
            {
                Log.Write("Lost Discord: " + e.Message);
                discord.Dispose();
                nextConnect = DateTime.Now.AddSeconds(5);
            }
        }

        // One's own status: sent when it is set or changed, or its picture comes,
        // with the same limit as a track's. Its time counts from when it was set.
        void Own()
        {
            var title = settings.OwnTitle.Trim();
            var key = "own|" + settings.OwnType + "|" + title + "|" + settings.OwnLine2.Trim() + "|" + settings.OwnMinutes;
            if (key != ownKey)
            {
                ownKey = key;
                ownStart = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - settings.OwnMinutes * 60000L;
            }
            // Safe build: no image upload or remote image URL.
            string image = null;
            var isResend = resendAt.HasValue && DateTime.Now >= resendAt.Value;
            var changed = key != sentKey || image != sentImage || isResend;
            if (!changed || (DateTime.Now - sentAt).TotalSeconds < 4) return;
            if (isResend) resendAt = null;
            try
            {
                var activity = Activity.Own(settings.OwnType, title, settings.OwnLine2, ownStart, image, settings.ActivityNameOverride);
                if (discord.SetActivity(activity) != null && Activity.UseLinks)
                {
                    Activity.UseLinks = false;
                    discord.SetActivity(Activity.Own(settings.OwnType, title, settings.OwnLine2, ownStart, image, settings.ActivityNameOverride));
                }
                Log.Write("Status: own, " + title + " (no picture)");
                shownKey = null; sentKey = key; sentImage = image; sentStart = null; sentDuration = 0; sentPlaying = null; sentAt = DateTime.Now;
            }
            catch (Exception e)
            {
                Log.Write("Lost Discord: " + e.Message); discord.Dispose(); nextConnect = DateTime.Now.AddSeconds(5);
            }
        }

        // What to show: what plays, a track with a known length first (a video
        // feed in the browser usually has none), then the one already shown,
        // then the one Windows calls current. On pause: only with showPaused.
        Track Pick(List<Track> sessions)
        {
            var visible = sessions.Where(t => !IsHidden(t)).ToList();
            var pool = visible.Where(t => t.IsPlaying).ToList();
            if (pool.Count == 0 && settings.ShowPaused) pool = visible;
            if (pool.Count == 0) return null;
            var timed = pool.Where(t => t.Duration > 0).ToList();
            if (timed.Count > 0) pool = timed;
            return pool.FirstOrDefault(t => t.Key == shownKey)
                ?? pool.FirstOrDefault(t => t.IsCurrent)
                ?? pool[0];
        }

        bool IsHidden(Track track)
        {
            return settings.Hides(track.App, track.Source.Name);
        }

        // When the track started, Unix ms; null when the app tells neither a
        // length nor a position. Without a length but with a position (Telegram
        // may give one) the start is still known: Discord then shows the right
        // time for a track started midway, and a repeat is a seek back to 0.
        // Worked out again only when the app reports something new: the Yandex
        // Music app keeps one position while it plays, the start worked out
        // from the clock crept on a second a second, every 4 s the status went
        // again as a seek, and Discord stopped passing it on to anyone else.
        long? StartFor(Track track)
        {
            var now = TimelineNow();
            var sameTrack = track.Key == timelineKey;
            var samePlayback = sameTrack && track.IsPlaying == timelinePlaying;
            var positionChanged = !sameTrack || track.Position != timelinePosition;
            if (track.Duration <= 0 && track.Position <= 0 && track.UpdatedAt == 0)
            {
                // A temporary missing report must not erase a known running clock.
                if (samePlayback && timelineStart.HasValue) return timelineStart;
                timelineKey = track.Key;
                timelinePlaying = track.IsPlaying;
                timelinePosition = track.Position;
                timelineUpdated = track.UpdatedAt;
                timelineStart = null;
                return null;
            }
            if (samePlayback && timelineStart.HasValue && !positionChanged)
            {
                // Some players refresh LastUpdatedTime without moving Position.
                // Keep the established clock instead of repeatedly moving it backwards.
                timelineUpdated = track.UpdatedAt;
                return timelineStart;
            }
            var updatedAt = sameTrack && track.UpdatedAt == timelineUpdated ? 0 : track.UpdatedAt;
            long candidate;
            if (sameTrack && !samePlayback && timelineStart.HasValue && !positionChanged)
            {
                // Pause/resume may arrive before the player refreshes its position.
                var position = timelinePlaying ? Math.Max(0, now - timelineStart.Value) / 1000.0 : timelinePausedPosition;
                if (track.Duration > 0) position = Math.Min(position, track.Duration);
                candidate = now - (long)(position * 1000);
            }
            else
            {
                candidate = StartedAt(track, updatedAt, now);
            }
            // Sub-second rounding in coarse player reports is not a seek.
            if (samePlayback && track.IsPlaying && timelineStart.HasValue && Math.Abs(candidate - timelineStart.Value) <= 1500)
                candidate = timelineStart.Value;
            timelineKey = track.Key;
            timelinePlaying = track.IsPlaying;
            timelinePosition = track.Position;
            timelineUpdated = track.UpdatedAt;
            timelineStart = candidate;
            if (!track.IsPlaying) timelinePausedPosition = Math.Max(0, now - candidate) / 1000.0;
            return timelineStart;
        }

        internal bool TimingChanged(Track track, long? start)
        {
            if (start.HasValue != sentStart.HasValue) return true;
            if (!start.HasValue) return false;
            var duration = DurationMillis(track);
            return Math.Abs(start.Value - sentStart.Value) > 3000 ||
                (duration == 0) != (sentDuration == 0) || Math.Abs(duration - sentDuration) >= 1000;
        }

        static long DurationMillis(Track track)
        {
            return track == null || track.Duration <= 0 ? 0 : (long)(track.Duration * 1000);
        }

        static long StartedAt(Track track, long updatedAt, long now)
        {
            var position = track.Position * 1000;
            // The position is as of updatedAt; it has played on since.
            if (track.IsPlaying && updatedAt > 0) position += Math.Max(0, now - updatedAt);
            if (track.Duration > 0) position = Math.Min(position, track.Duration * 1000);
            return now - (long)position;
        }

        public static string Describe(Track track)
        {
            var line = track.Artist != "" ? track.Artist + " — " + track.Title : track.Title;
            return line + " · " + track.Source.Name;
        }

        // The error underneath the task and reflection wrappers:
        // "One or more errors occurred" alone says nothing.
        static Exception Unwrap(Exception e)
        {
            while ((e is AggregateException || e is System.Reflection.TargetInvocationException) && e.InnerException != null)
            {
                e = e.InnerException;
            }
            return e;
        }

        static string Describe(Exception e)
        {
            return e.GetType().Name + " 0x" + e.HResult.ToString("X8") + ": " + e.Message;
        }

        void Report(string status)
        {
            if (status == Status) return;
            Status = status;
            var handler = Changed;
            if (handler != null) handler();
        }
    }
}

