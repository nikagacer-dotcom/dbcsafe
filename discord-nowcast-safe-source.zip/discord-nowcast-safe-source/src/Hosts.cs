using System;
using System.Text.RegularExpressions;
namespace Nowcast
{
    // Safe build: no HTTP clients or network upload implementation.
    static class Hosts
    {
        public class Uploaded { public string Url; public TimeSpan Keep; }
        public class Rejected : InvalidOperationException
        {
            public readonly int Status;
            public Rejected(int status, string message) : base(status + " " + message) { Status = status; }
        }
        public static Uploaded Upload(byte[] image) { throw new NotSupportedException("Network uploads are disabled in this safe build."); }
        public static Uploaded UploadOwn(byte[] image) { throw new NotSupportedException("Network uploads are disabled in this safe build."); }
        public static Uploaded UploadOwn(byte[] image, string slot) { throw new NotSupportedException("Network uploads are disabled in this safe build."); }
        internal static string EncodedNick(string nick)
        {
            nick = (nick ?? "").Trim();
            int end = 0, count = 0;
            while (end < nick.Length && count++ < 80)
            {
                if (char.IsHighSurrogate(nick[end]) && end + 1 < nick.Length && char.IsLowSurrogate(nick[end + 1])) end++;
                end++;
            }
            return end == 0 ? null : Uri.EscapeDataString(nick.Substring(0, end));
        }
    }
}
