using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Nowcast
{
    // A line of a song's text and when it is sung, ms from the start.
    class LyricLine
    {
        public long At;
        public string Text;
    }

    // The song's text with timings from lrclib.net, an open database: the line
    // sung now goes into the status. Looked up once per track in the
    // background; a failed lookup is tried again, 2 … 60 s apart, while the
    // track plays. Discord takes a status every 4 s, so a quick line can be
    // skipped: the status shows the line of the moment it goes out.
    static class Lyrics
    {
        // By track: its lines, empty when the database has no timed text.
        static readonly Dictionary<string, List<LyricLine>> found = new Dictionary<string, List<LyricLine>>();
        static readonly Dictionary<string, Task<List<LyricLine>>> pending = new Dictionary<string, Task<List<LyricLine>>>();
        static readonly Dictionary<string, DateTime> retryAt = new Dictionary<string, DateTime>();
        static readonly Dictionary<string, int> failures = new Dictionary<string, int>();

        // Stand-ins for the tests: the clock and the lookup (null: failed, try again).
        public static Func<DateTime> Now = delegate { return DateTime.Now; };
        public static Func<Track, List<LyricLine>> LookUp = delegate(Track track) { return null; };

        // Raised when a lookup is done, so the line goes out without waiting a round.
        public static event Action Ready;

        // The track's lines, or null while they are looked for or when there are none.
        public static List<LyricLine> Find(Track track)
        {
            // Safe build: no external lyrics requests.
            return null;
        }

        public static void Reset()
        {
            found.Clear();
            pending.Clear();
            retryAt.Clear();
            failures.Clear();
        }

        // The line sung at ms from the start: null before the first, "♪" for a
        // pause between lines.
        public static string Line(List<LyricLine> lines, long ms)
        {
            if (lines == null) return null;
            string line = null;
            foreach (var next in lines)
            {
                if (next.At > ms) break;
                line = next.Text;
            }
            if (line == null) return null;
            return line.Trim() == "" ? "♪" : line.Trim();
        }

        static readonly Regex stamp = new Regex(@"\[(\d+):(\d+(?:[.,]\d+)?)\]");

        // LRC: "[01:02.50]words", several times before one line when it repeats.
        public static List<LyricLine> Parse(string lrc)
        {
            var lines = new List<LyricLine>();
            if (string.IsNullOrEmpty(lrc)) return lines;
            foreach (var raw in lrc.Split('\n'))
            {
                var matches = stamp.Matches(raw);
                if (matches.Count == 0) continue;
                var last = matches[matches.Count - 1];
                var text = raw.Substring(last.Index + last.Length).Trim();
                foreach (Match match in matches)
                {
                    var minutes = int.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
                    var seconds = double.Parse(match.Groups[2].Value.Replace(',', '.'), CultureInfo.InvariantCulture);
                    lines.Add(new LyricLine { At = (long)((minutes * 60 + seconds) * 1000), Text = text });
                }
            }
            lines.Sort(delegate(LyricLine a, LyricLine b) { return a.At.CompareTo(b.At); });
            return lines;
        }

        // In the background: the timed text from lrclib.net, by artist, title and
        // length; empty when there is none, null when the site could not be asked.
        static List<LyricLine> FromLrclib(Track track)
        {
            // Safe build: external lyrics search is disabled.
            return null;
        }

        // The reply as JSON; an empty object for "not found", null when the site did not answer.
        static object Get(string url)
        {
            // Safe build: external HTTP requests are disabled.
            return null;
        }
    }
}
