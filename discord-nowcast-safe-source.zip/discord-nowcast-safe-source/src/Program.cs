// discord-nowcast: shows the track playing in any Windows app as your
// Discord status, with a tray icon to control it.
//
// Built by build.ps1 with the C# compiler that ships with .NET Framework
// 4.8, so the code stays within C# 5: no string interpolation, no ?.,
// no expression-bodied members.

using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace Nowcast
{
    static class Program
    {
        // Raise with every release, together with a CHANGELOG.md entry.
        public const string Version = "1.7.1";
        public const string Repo = "playsin333/discord-nowcast";
        // The project's Discord server: questions, bugs, screenshots of the status.
        public const string DiscordInvite = "https://discord.gg/udz3TTZgPD";

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // One copy at a time; a killed copy leaves the mutex abandoned,
            // which is ours to take.
            var mutex = new Mutex(false, "Local\\discord-nowcast");
            bool isFirst;
            try
            {
                isFirst = mutex.WaitOne(1000);
            }
            catch (AbandonedMutexException)
            {
                isFirst = true;
            }
            if (!isFirst)
            {
                MessageBox.Show(Text.AlreadyRunning, "discord-nowcast", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Log.Start();
            Log.Write("discord-nowcast " + Version + " " + Application.ExecutablePath);
            try
            {
                Application.Run(new TrayApp());
            }
            finally
            {
                mutex.ReleaseMutex();
            }
        }

        // A link in the browser (argument null), or a file in a program.
        public static void Open(string file, string argument)
        {
            try
            {
                if (argument == null) Process.Start(file);
                else Process.Start(file, "\"" + argument + "\"");
            }
            catch (Exception e)
            {
                Log.Write("Could not open " + file + ": " + e.Message);
            }
        }
    }
}
