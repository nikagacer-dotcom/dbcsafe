using System;
namespace Nowcast
{
    // Safe build: persistent startup registration is intentionally disabled.
    static class Startup
    {
        public static bool IsEnabled { get { return false; } }
        public static bool IsNewInstall { get { return false; } }
        public static void Enable() { }
        public static void Disable() { }
        public static void Refresh() { }
        public static void Install() { }
    }
}
