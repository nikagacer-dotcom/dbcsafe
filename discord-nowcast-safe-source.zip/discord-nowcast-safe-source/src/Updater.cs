namespace Nowcast
{
    // Safe build: update checks are intentionally disabled.
    static class Updater
    {
        public static string ReleasesUrl { get { return "https://github.com/playsin333/discord-nowcast/releases"; } }
        public static string FindNewer() { return null; }
        internal static string NewerTag(string text) { return null; }
    }
}
